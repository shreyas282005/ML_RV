"""Run ONNX Runtime inference through Ultralytics and save images plus CSV."""
import argparse
import time
from pathlib import Path
import cv2
import pandas as pd
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='models/best.onnx')
    parser.add_argument('--images', default='dataset/images/test')
    parser.add_argument('--output', default='results/onnx_predictions')
    parser.add_argument('--csv', default='results/onnx_predictions.csv')
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--conf', type=float, default=0.25)
    args = parser.parse_args()

    model_path, image_dir = Path(args.model), Path(args.images)
    if not model_path.is_file(): raise FileNotFoundError(model_path)
    if not image_dir.is_dir(): raise FileNotFoundError(image_dir)
    images = sorted(p for p in image_dir.iterdir() if p.suffix.lower() in {'.png', '.jpg', '.jpeg'})
    if not images: raise RuntimeError(f'No images found in {image_dir}')

    out_dir, csv_path = Path(args.output), Path(args.csv)
    out_dir.mkdir(parents=True, exist_ok=True); csv_path.parent.mkdir(parents=True, exist_ok=True)
    model = YOLO(str(model_path), task='detect')
    rows, times = [], []
    for image_path in images:
        start = time.perf_counter()
        result = model.predict(source=str(image_path), imgsz=args.imgsz, conf=args.conf, verbose=False)[0]
        times.append((time.perf_counter() - start) * 1000)
        if not cv2.imwrite(str(out_dir / image_path.name), result.plot()):
            raise RuntimeError(f'Could not save annotated image: {image_path.name}')
        for box in result.boxes:
            class_id = int(box.cls[0]); x1, y1, x2, y2 = box.xyxy[0].tolist()
            rows.append({'image_name': image_path.name, 'class_id': class_id,
                         'class_name': model.names[class_id], 'confidence': round(float(box.conf[0]), 4),
                         'x_min': round(x1, 2), 'y_min': round(y1, 2),
                         'x_max': round(x2, 2), 'y_max': round(y2, 2)})
    df = pd.DataFrame(rows, columns=['image_name','class_id','class_name','confidence','x_min','y_min','x_max','y_max'])
    df.to_csv(csv_path, index=False)
    print(f'Images: {len(images)} | Detections: {len(df)} | Average inference: {sum(times)/len(times):.2f} ms/image')
    print(f'Annotated images: {out_dir}\nCSV: {csv_path}')

if __name__ == '__main__': main()

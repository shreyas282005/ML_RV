"""Train YOLOv8n using the prepared train/validation dataset."""
import argparse
from pathlib import Path
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='dataset/data.yaml')
    parser.add_argument('--weights', default='yolov8n.pt')
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--batch', type=int, default=16)
    parser.add_argument('--device', default='0', help="Use 'cpu' if no GPU is available")
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--project', default='training_runs')
    parser.add_argument('--name', default='yolov8n_training')
    args = parser.parse_args()

    data_path = Path(args.data).resolve()
    if not data_path.is_file():
        raise FileNotFoundError(f'Dataset YAML not found: {data_path}')

    model = YOLO(args.weights)
    model.train(
        data=str(data_path), epochs=args.epochs, imgsz=args.imgsz,
        batch=args.batch, device=args.device, patience=args.patience,
        seed=42, project=args.project, name=args.name, exist_ok=True
    )


if __name__ == '__main__':
    main()

"""Measure detected shapes with OpenCV and create the assignment's 17-column CSV."""
import argparse
from pathlib import Path
import cv2
import numpy as np
import pandas as pd

CLASS_NAMES = {0: 'circle', 1: 'square', 2: 'triangle', 3: 'rectangle'}
SHAPES = ['circle', 'square', 'triangle', 'rectangle']


def segment_object(crop):
    """Use the notebook's HSV method, then its border-colour fallback."""
    if crop.size == 0:
        return None, None
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    difference = cv2.absdiff(hsv, hsv[0, 0])
    gray_difference = cv2.cvtColor(difference, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray_difference, 15, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        candidate = max(contours, key=cv2.contourArea)
        if cv2.contourArea(candidate) > 0 and cv2.moments(candidate)['m00'] > 0:
            return candidate, False

    border = np.concatenate([crop[0,:,:], crop[-1,:,:], crop[:,0,:], crop[:,-1,:]])
    background = np.median(border, axis=0)
    difference = np.abs(crop.astype(np.int16) - background.astype(np.int16))
    binary = (np.max(difference, axis=2) > 30).astype(np.uint8) * 255
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, True
    candidate = max(contours, key=cv2.contourArea)
    if cv2.contourArea(candidate) <= 0 or cv2.moments(candidate)['m00'] == 0:
        return None, True
    return candidate, True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--images', default='dataset/images')
    parser.add_argument('--predictions', default='results/pt_predictions.csv')
    parser.add_argument('--output', default='results/opencv_annotated')
    parser.add_argument('--csv', default='results/final_results.csv')
    args = parser.parse_args()

    image_dir, pred_path = Path(args.images), Path(args.predictions)
    if not image_dir.is_dir(): raise FileNotFoundError(image_dir)
    if not pred_path.is_file(): raise FileNotFoundError(pred_path)
    output_dir, csv_path = Path(args.output), Path(args.csv)
    output_dir.mkdir(parents=True, exist_ok=True); csv_path.parent.mkdir(parents=True, exist_ok=True)
    predictions = pd.read_csv(pred_path)
    required = {'image_name','class_id','x_min','y_min','x_max','y_max'}
    if not required.issubset(predictions.columns):
        raise ValueError(f'Prediction CSV must contain: {sorted(required)}')

    rows, processed, failed, fallback_count = [], 0, 0, 0
    image_paths = sorted(p for p in image_dir.iterdir() if p.suffix.lower() in {'.png','.jpg','.jpeg'})
    for image_path in image_paths:
        image = cv2.imread(str(image_path))
        if image is None: continue
        image_name = image_path.name
        detections = predictions[predictions.image_name == image_name]
        shape_data = {name: {'areas': [], 'centers': [], 'defects': []} for name in SHAPES}

        for _, det in detections.iterrows():
            class_id = int(det['class_id'])
            if class_id not in CLASS_NAMES: continue
            class_name = CLASS_NAMES[class_id]
            margin = 5
            x1 = max(0, int(det.x_min) - margin); y1 = max(0, int(det.y_min) - margin)
            x2 = min(image.shape[1], int(det.x_max) + margin); y2 = min(image.shape[0], int(det.y_max) + margin)
            crop = image[y1:y2, x1:x2]
            contour, used_fallback = segment_object(crop)
            if used_fallback:
                fallback_count += 1
                margin = 10
                x1 = max(0, int(det.x_min) - margin); y1 = max(0, int(det.y_min) - margin)
                x2 = min(image.shape[1], int(det.x_max) + margin); y2 = min(image.shape[0], int(det.y_max) + margin)
                crop = image[y1:y2, x1:x2]
                contour, _ = segment_object_fallback_only(crop)
            if contour is None:
                failed += 1; continue
            area = float(cv2.contourArea(contour)); moments = cv2.moments(contour)
            if area <= 0 or moments['m00'] == 0:
                failed += 1; continue
            cx = int(moments['m10'] / moments['m00']) + x1
            cy = int(moments['m01'] / moments['m00']) + y1
            defect = 'less_defect' if area < 5000 else ('moderate_defect' if area <= 15000 else 'severe_defect')
            shape_data[class_name]['areas'].append(round(area, 2))
            shape_data[class_name]['centers'].append([cx, cy])
            shape_data[class_name]['defects'].append(defect)
            processed += 1
            cv2.rectangle(image, (x1,y1), (x2,y2), (0,255,0), 2)
            full = contour.copy(); full[:,0,0] += x1; full[:,0,1] += y1
            cv2.drawContours(image, [full], -1, (255,0,0), 2)
            cv2.circle(image, (cx,cy), 6, (0,0,255), -1)
            cv2.putText(image, f'{class_name} | {defect}', (x1,max(20,y1-8)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,0), 2)

        row = {'image_name': image_name}
        for name in SHAPES:
            class_id = SHAPES.index(name)
            count = int((detections.class_id == class_id).sum())
            row[f'{name}_count'] = [count]
            row[f'{name}_area_px2'] = shape_data[name]['areas']
            row[f'{name}_center'] = shape_data[name]['centers']
            row[f'{name}_defect'] = shape_data[name]['defects']
        rows.append(row)
        cv2.imwrite(str(output_dir / image_name), image)

    columns = ['image_name'] + [f'{s}_{field}' for s in SHAPES for field in ['count','area_px2','center','defect']]
    pd.DataFrame(rows, columns=columns).to_csv(csv_path, index=False)
    print(f'Images processed: {len(rows)} | Measurements: {processed} | Failed: {failed} | Fallback used: {fallback_count}')
    print(f'Annotated images: {output_dir}\nFinal CSV: {csv_path}')


def segment_object_fallback_only(crop):
    if crop.size == 0: return None, True
    border = np.concatenate([crop[0,:,:], crop[-1,:,:], crop[:,0,:], crop[:,-1,:]])
    background = np.median(border, axis=0)
    difference = np.abs(crop.astype(np.int16) - background.astype(np.int16))
    binary = (np.max(difference, axis=2) > 30).astype(np.uint8) * 255
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours: return None, True
    contour = max(contours, key=cv2.contourArea)
    if cv2.contourArea(contour) <= 0 or cv2.moments(contour)['m00'] == 0: return None, True
    return contour, True


if __name__ == '__main__': main()

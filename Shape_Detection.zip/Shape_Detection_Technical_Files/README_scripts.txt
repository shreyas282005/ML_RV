Standalone scripts for Shape Detection, Measurement and Defect Classification

These scripts mirror the workflow and main settings in the supplied notebook.
They are intended to run from the root of the extracted project folder.

Install dependencies:
  pip install ultralytics opencv-python pandas numpy onnx onnxruntime

PyTorch inference:
  python inference_pytorch.py --model models/best.pt --images dataset/images/test --output results/pytorch_predictions --csv results/pt_predictions.csv --device cpu

ONNX inference:
  python inference_onnx.py --model models/best.onnx --images dataset/images/test --output results/onnx_predictions --csv results/onnx_predictions.csv

OpenCV measurements for all 200 images (uses PyTorch prediction CSV):
  python opencv_measurement.py --images dataset/images --predictions results/pt_predictions.csv --output results/opencv_annotated --csv results/final_results.csv

Training (only if training needs to be repeated; not required for the already-trained model):
  python train.py --data dataset/data.yaml --epochs 100 --imgsz 640 --batch 16 --device 0
  Use --device cpu if no GPU is available.

Note: training is not required for the current final evaluation. The OpenCV script produces the required 17-column CSV format.
